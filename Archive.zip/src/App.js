import logo from "./logo.svg";
import "./App.css";
// import Images from "./utils/Images";
import Login from "./components/Login";
function App() {
  return (
    <div className="App">
      <Login />
    </div>
  );
}

export default App;
