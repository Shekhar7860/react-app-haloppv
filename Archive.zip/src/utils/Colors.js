const Colors = {
  appBackGroundColor: "#303030",
  buttonTextColor: "#D78143",
  PrimaryColor: "#263146",
  White: "white",
  GradColor: ["#27a51e", "#b1db99"],
  green: "#27a51e",
  lightGreen: "#b1db99",
  backGrayColor: "#F7F7F7",
};
export default Colors;
