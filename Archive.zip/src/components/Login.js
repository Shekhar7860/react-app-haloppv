import React from "react";
import { Form, Button } from "react-bootstrap";
import Colors from "../utils/Colors";
import logo from "../assets/halosun.png";

export default function Login() {
  function NewMeetupForm() {}

  function submitHandler(event) {
    event.preventDefault();
  }

  return (
    <>
      <div className="header-background"></div>
      <div className="content">
        <div className="box">
          <h3>SignIn</h3>
          <form>
            <div className="login-form">
              <label>Login</label>
              <input type="text" />
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
